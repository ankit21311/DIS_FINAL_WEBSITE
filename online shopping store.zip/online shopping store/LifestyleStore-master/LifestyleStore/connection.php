<?php
$con=mysqli_connect("localhost","id2538044_sajalagrawal","******","id2538044_store") or die(mysqli_error($con));
//$con=mysqli_connect("localhost","root","","store") or die(mysqli_error($con));
?>
